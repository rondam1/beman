function loadpage(){
while (bedcount in ward)
  {
    loadBeds();
	loadPatients();
  }
}

function loadBeds(){
  load html;
}

function loadPatients(){
  retrieve patients assigned to ward bed;
  display results on button
}

function addInPatient(){
  Add inpatient record
  loadpatients;
}

function removeInPatient(){
  remove inPatient record;
  loadpatients;
}